"""SquadForge backend package."""
